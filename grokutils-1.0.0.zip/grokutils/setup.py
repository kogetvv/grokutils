from setuptools import setup, find_packages

setup(
    name="grokutils",
    version="1.0.0",
    author="Grok (xAI)",
    author_email="grok@x.ai",
    description="A fun utility library inspired by Grok — helpers for text, math and everyday Python tasks.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    license="MIT",
)
