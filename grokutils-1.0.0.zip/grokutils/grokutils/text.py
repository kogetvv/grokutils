"""
Text processing utilities.
"""

import re
from typing import List


def slugify(text: str, separator: str = "-") -> str:
    """
    Convert text to a URL-friendly slug.

    >>> slugify("Hello World! How are you?")
    'hello-world-how-are-you'
    """
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_-]+", separator, text)
    return text.strip(separator)


def camel_to_snake(name: str) -> str:
    """
    Convert CamelCase to snake_case.

    >>> camel_to_snake("HelloWorldExample")
    'hello_world_example'
    """
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()


def snake_to_camel(name: str, capitalize_first: bool = True) -> str:
    """
    Convert snake_case to CamelCase (or camelCase).

    >>> snake_to_camel("hello_world_example")
    'HelloWorldExample'
    >>> snake_to_camel("hello_world", capitalize_first=False)
    'helloWorld'
    """
    components = name.split("_")
    if not components:
        return ""
    if capitalize_first:
        return "".join(x.title() for x in components)
    return components[0] + "".join(x.title() for x in components[1:])


def word_count(text: str) -> int:
    """
    Count words in a string (simple whitespace split).

    >>> word_count("Hello world, how are you?")
    5
    """
    return len(text.split())


def extract_emails(text: str) -> List[str]:
    """
    Extract email addresses from text.

    >>> extract_emails("Contact us at info@example.com or support@test.org")
    ['info@example.com', 'support@test.org']
    """
    pattern = r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"
    return re.findall(pattern, text)
