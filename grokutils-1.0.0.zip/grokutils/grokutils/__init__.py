"""
grokutils - A fun utility library inspired by Grok and xAI.

Provides handy helpers for text, math, and everyday Python tasks.
Version: 1.0.0
"""

from .core import (
    greet,
    reverse_words,
    fibonacci,
    is_prime,
    flatten,
    chunk_list,
    unique_preserve_order,
    safe_divide,
    clamp,
)

from .text import (
    slugify,
    camel_to_snake,
    snake_to_camel,
    word_count,
    extract_emails,
)

__version__ = "1.0.0"
__author__ = "Grok (xAI)"
__all__ = [
    "greet",
    "reverse_words",
    "fibonacci",
    "is_prime",
    "flatten",
    "chunk_list",
    "unique_preserve_order",
    "safe_divide",
    "clamp",
    "slugify",
    "camel_to_snake",
    "snake_to_camel",
    "word_count",
    "extract_emails",
]
