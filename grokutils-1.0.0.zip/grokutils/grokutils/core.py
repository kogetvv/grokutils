"""
Core utilities of grokutils.
"""

from typing import Any, Iterable, List, Optional, TypeVar, Union
import math

T = TypeVar("T")


def greet(name: str = "traveler") -> str:
    """
    Friendly greeting in the spirit of Grok.

    >>> greet("Alice")
    'Hello, Alice! Ready to understand the universe?'
    """
    return f"Hello, {name}! Ready to understand the universe?"


def reverse_words(text: str) -> str:
    """
    Reverse the order of words in a string.

    >>> reverse_words("hello beautiful world")
    'world beautiful hello'
    """
    return " ".join(reversed(text.split()))


def fibonacci(n: int) -> List[int]:
    """
    Generate the first n Fibonacci numbers.

    >>> fibonacci(7)
    [0, 1, 1, 2, 3, 5, 8]
    """
    if n < 0:
        raise ValueError("n must be non-negative")
    if n == 0:
        return []
    seq = [0, 1]
    while len(seq) < n:
        seq.append(seq[-1] + seq[-2])
    return seq[:n]


def is_prime(num: int) -> bool:
    """
    Check whether a number is prime.

    >>> is_prime(17)
    True
    >>> is_prime(15)
    False
    """
    if num <= 1:
        return False
    if num <= 3:
        return True
    if num % 2 == 0 or num % 3 == 0:
        return False
    i = 5
    while i * i <= num:
        if num % i == 0 or num % (i + 2) == 0:
            return False
        i += 6
    return True


def flatten(nested: Iterable[Any], depth: Optional[int] = None) -> List[Any]:
    """
    Flatten a nested iterable.

    >>> flatten([1, [2, [3, 4]], 5])
    [1, 2, 3, 4, 5]
    >>> flatten([1, [2, [3, 4]], 5], depth=1)
    [1, 2, [3, 4], 5]
    """
    result: List[Any] = []
    for item in nested:
        if isinstance(item, (list, tuple)) and (depth is None or depth > 0):
            result.extend(flatten(item, None if depth is None else depth - 1))
        else:
            result.append(item)
    return result


def chunk_list(lst: List[T], size: int) -> List[List[T]]:
    """
    Split a list into chunks of given size.

    >>> chunk_list([1, 2, 3, 4, 5], 2)
    [[1, 2], [3, 4], [5]]
    """
    if size <= 0:
        raise ValueError("size must be positive")
    return [lst[i : i + size] for i in range(0, len(lst), size)]


def unique_preserve_order(items: Iterable[T]) -> List[T]:
    """
    Return unique items while preserving order of first appearance.

    >>> unique_preserve_order([3, 1, 2, 1, 3, 4])
    [3, 1, 2, 4]
    """
    seen = set()
    result = []
    for item in items:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result


def safe_divide(a: Union[int, float], b: Union[int, float], default: float = 0.0) -> float:
    """
    Divide a by b, returning default on ZeroDivisionError.

    >>> safe_divide(10, 2)
    5.0
    >>> safe_divide(10, 0)
    0.0
    """
    try:
        return a / b
    except ZeroDivisionError:
        return default


def clamp(value: Union[int, float], min_val: Union[int, float], max_val: Union[int, float]) -> Union[int, float]:
    """
    Clamp a value between min_val and max_val.

    >>> clamp(15, 0, 10)
    10
    >>> clamp(-5, 0, 10)
    0
    """
    return max(min_val, min(value, max_val))
